from pupa.scrape import Scraper
from pupa.scrape import VoteEvent


class SacramentoVoteEventScraper(Scraper):

    def scrape(self):
        # needs to be implemented
        pass
