from pupa.scrape import Scraper
from pupa.scrape import Event


class SacramentoEventScraper(Scraper):

    def scrape(self):
        # needs to be implemented
        pass
