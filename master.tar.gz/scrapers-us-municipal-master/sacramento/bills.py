from pupa.scrape import Scraper
from pupa.scrape import Bill


class SacramentoBillScraper(Scraper):

    def scrape(self):
        # needs to be implemented
        pass
